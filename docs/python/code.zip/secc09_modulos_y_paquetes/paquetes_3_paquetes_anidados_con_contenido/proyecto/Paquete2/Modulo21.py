# ejemplo de paquete con modulos anidados
#
#  proyecto/
#  |-- __init__.py
#  |-- Modulo1.py
#  |-- Modulo2.py 
#  |-- Paquete1/
#  |   |-- __init__.py
#  |   |-- Modulo11.py
#  |   `-- Paquete11/
#  |       `-- __init__.py
#  `-- Paquete2/
#      |-- __init__.py
#      `-- Modulo21.py  <--- Estamos aqui
#


contenido = "Hola desde: proyecto/Paquete2/Modulo21.py"




